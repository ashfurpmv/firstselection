// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
import java.util.Scanner;
public class Main {

  static class Item {
      String name;
      double price;

      Item(String name, double price) {
          this.name = name;
          this.price = price;
      }

      @Override
      public String toString() {
          return name + " - $" + String.format("%.2f", price);
      }
  }
  
  public static void main(String[] args) {
    Scanner keyedInput = new Scanner(System.in);
    boolean operational = true;
    double amountSpent = 0;
    String couponCode;
    int FSP = 0;
    double amountSaved;

    

    while (operational)
    {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Please choose an option:");
        System.out.println("1. View Frequent Shopper Points");
        System.out.println("2. Checkout");
        System.out.println("3. Exit");
        System.out.print("Enter your choice (1-3): ");
        

        int choice = keyedInput.nextInt();
        keyedInput.nextLine(); // Consume newline
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    

        switch (choice) 
        {
            
          case 1:
            System.out.println("Frequent Shopper Points: " + FSP);
            break;

          case 2:
            System.out.println("Enter amount spent: ");
            amountSpent = keyedInput.nextDouble();
            keyedInput.nextLine(); // Consume newline
            System.out.println("Would you like to use your frequent shoppers points? (y/n): ");
            String usePoints = keyedInput.nextLine();
            
            if (usePoints.equalsIgnoreCase("y"))
            {
              //System.out.println("How many points would you like to use?: ");
              //int pointsUsed = keyedInput.nextInt();
              //keyedInput.nextLine(); // Consume newline
              //if (pointsUsed > FSP)
                
              System.out.println("Great! You will save an additional $" + FSP + " on your initial spending");
              amountSpent = amountSpent - FSP;
              System.out.println("You new amount spent is: $" + amountSpent);
              System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            else
            {
              System.out.println("Ok! Proceeding to checkout!");
              System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            }
            
            if (amountSpent <= 40)
            {
              
              double iamountSpent = amountSpent;
              amountSaved = amountSpent * 0.1;
              amountSpent = amountSpent - amountSaved;
              int fspgained = (int) (iamountSpent * 0.1);
              FSP = FSP + fspgained;
              //round saved
              amountSaved = amountSaved * 100;
              amountSaved = Math.round(amountSaved);
              amountSaved = amountSaved / 100;
              //round total
              amountSpent = amountSpent * 100;
              amountSpent = Math.round(amountSpent);
              amountSpent = amountSpent / 100;
              //output results
              System.out.println("You spent: $" + String.format("%.2f",iamountSpent));
              System.out.println("You are saving 10%");
              System.out.println("You are saving: $" + String.format("%.2f",amountSaved));
              System.out.println("Your total is: $" + String.format("%.2f",amountSpent));
              System.out.println("Frequent Shopper Points Gained: " + fspgained);
            }
            else if (amountSpent > 40 && amountSpent <= 80)
              {
                double iamountSpent = amountSpent;
                amountSaved = amountSpent * 0.2;
                amountSpent = amountSpent - amountSaved;
                int fspgained = (int) (iamountSpent * 0.1);
                FSP = FSP + fspgained;
                //round saved
                amountSaved = amountSaved * 100;
                amountSaved = Math.round(amountSaved);
                amountSaved = amountSaved / 100;
                //round total
                amountSpent = amountSpent * 100;
                amountSpent = Math.round(amountSpent);
                amountSpent = amountSpent / 100;
                //output results
                System.out.println("You spent: $" + String.format("%.2f",iamountSpent));
                System.out.println("You are saving 20%");
                System.out.println("You are saving: $" + String.format("%.2f",amountSaved));
                System.out.println("Your total is: $" + String.format("%.2f",amountSpent));
                System.out.println("Frequent Shopper Points Gained: " + fspgained);
              }
            else if (amountSpent > 80 && amountSpent <= 120)
              {
                double iamountSpent = amountSpent;
                amountSaved = amountSpent * 0.3;
                amountSpent = amountSpent - amountSaved;
                int fspgained = (int) (iamountSpent * 0.1);
                FSP = FSP + fspgained;
                //round saved
                amountSaved = amountSaved * 100;
                amountSaved = Math.round(amountSaved);
                amountSaved = amountSaved / 100;
                //round total
                amountSpent = amountSpent * 100;
                amountSpent = Math.round(amountSpent);
                amountSpent = amountSpent / 100;
                //output results
                System.out.println("You spent: $" + String.format("%.2f",iamountSpent));
                System.out.println("You are saving 30%");
                System.out.println("You are saving: $" + String.format("%.2f",amountSaved));
                System.out.println("Your total is: $" + String.format("%.2f",amountSpent));
                System.out.println("Frequent Shopper Points Gained: " + fspgained);
              }
            else if (amountSpent > 120)
              {
                double iamountSpent = amountSpent;
                amountSaved = amountSpent * 0.4;
                amountSpent = amountSpent - amountSaved;
                int fspgained = (int) (iamountSpent * 0.1);
                FSP = FSP + fspgained;
                //round saved
                amountSaved = amountSaved * 100;
                amountSaved = Math.round(amountSaved);
                amountSaved = amountSaved / 100;
                //round total
                amountSpent = amountSpent * 100;
                amountSpent = Math.round(amountSpent);
                amountSpent = amountSpent / 100;
                //output results
                System.out.println("You spent: $" + String.format("%.2f",iamountSpent));
                System.out.println("You are saving 40%");
                System.out.println("You are saving: $" + String.format("%.2f",amountSaved));
                System.out.println("Your total is: $" + String.format("%.2f",amountSpent));
                System.out.println("Frequent Shopper Points Gained: " + fspgained);
                
              }
            break;
            
          case 3:
            // Exit
            System.out.println("Exiting the program. Have a great day!");
            operational = false;
            break;
          

          default:
                System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                break;
              
            
          
        }
    }
              
                
              
          
    keyedInput.close();
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}